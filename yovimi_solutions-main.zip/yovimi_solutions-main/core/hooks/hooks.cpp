//#include "../../dependencies/utilities/csgo.hpp"
#include "../features/features.hpp"
#include "../features/misc/engine_prediction.hpp"
#include "../menu/menu.hpp"
#include "..\features\aim\backtrack.h"
#include "..\dependencies\cincludes.h"
#include "..\features\visuals\hitmarker.h"


hooks::create_move::fn create_move_original = nullptr;
hooks::paint_traverse::fn paint_traverse_original = nullptr;
hooks::frame_stage_notify::fn frame_stage_notify_original = nullptr;

bool hooks::initialize() {
	const auto create_move_target = reinterpret_cast<void*>(get_virtual(interfaces::clientmode, 24));
	const auto paint_traverse_target = reinterpret_cast<void*>(get_virtual(interfaces::panel, 41));
	auto viewmodel_fov_target = reinterpret_cast<void*>(get_virtual(interfaces::clientmode, 35));
	auto frame_stage_notify_target = reinterpret_cast<void*>(get_virtual(interfaces::client, 37));

	if (MH_Initialize() != MH_OK)
		throw std::runtime_error("failed to initialize MH_Initialize.");

	if (MH_CreateHook(create_move_target, &create_move::hook, reinterpret_cast<void**>(&create_move_original)) != MH_OK)
		throw std::runtime_error("failed to initialize create_move. (outdated index?)");

	if (MH_CreateHook(viewmodel_fov_target, &viewmodel_fov::hook, NULL) != MH_OK) {
		throw std::runtime_error("failed to initialize viewmodel_fov_hook. (outdated index?)");
		return false;
	}

	if (MH_CreateHook(frame_stage_notify_target, &frame_stage_notify::hook, reinterpret_cast<void**>(&frame_stage_notify_original)) != MH_OK) {
		throw std::runtime_error("failed to initialize frame_stage_notify. (outdated index?)");
		return false;
	}

	if (MH_CreateHook(paint_traverse_target, &paint_traverse::hook, reinterpret_cast<void**>(&paint_traverse_original)) != MH_OK)
		throw std::runtime_error("failed to initialize paint_traverse. (outdated index?)");

	if (MH_EnableHook(MH_ALL_HOOKS) != MH_OK)
		throw std::runtime_error("failed to enable hooks.");

	console::log("[setup] hooks initialized!\n");
	return true;
}

void hooks::release() {
	MH_Uninitialize();

	MH_DisableHook(MH_ALL_HOOKS);
}

bool __stdcall hooks::create_move::hook(float input_sample_frametime, c_usercmd* cmd) {
	create_move_original(input_sample_frametime, cmd);

	if (!cmd || !cmd->command_number)
		return false;

	csgo::local_player = static_cast<player_t*>(interfaces::entity_list->get_client_entity(interfaces::engine->get_local_player()));

	uintptr_t* frame_pointer;
	__asm mov frame_pointer, ebp;
	bool& send_packet = *reinterpret_cast<bool*>(*frame_pointer - 0x1C);

	auto old_viewangles = cmd->viewangles;
	auto old_forwardmove = cmd->forwardmove;
	auto old_sidemove = cmd->sidemove;

	

	misc::movement::bunny_hop(cmd);

	prediction::start(cmd); {
		aimbot::aim(cmd);
		backtrack.run(cmd);
	} prediction::end();

	if (variables::nade) {
		interfaces::console->get_convar("cl_grenadepreview")->set_value(1);
	}
	else {
		interfaces::console->get_convar("cl_grenadepreview")->set_value(0);
	}


	cmd->forwardmove = std::clamp(cmd->forwardmove, -450.0f, 450.0f);
	cmd->sidemove = std::clamp(cmd->sidemove, -450.0f, 450.0f);
	cmd->upmove = std::clamp(cmd->upmove, -320.0f, 320.0f);

	misc::clantag();


	math::correct_movement(old_viewangles, cmd, old_forwardmove, old_sidemove);

	cmd->forwardmove = std::clamp(cmd->forwardmove, -450.0f, 450.0f);
	cmd->sidemove = std::clamp(cmd->sidemove, -450.0f, 450.0f);
	cmd->upmove = std::clamp(cmd->upmove, -320.0f, 320.0f);

	cmd->viewangles.normalize();
	cmd->viewangles.x = std::clamp(cmd->viewangles.x, -89.0f, 89.0f);
	cmd->viewangles.y = std::clamp(cmd->viewangles.y, -180.0f, 180.0f);
	cmd->viewangles.z = 0.0f;

	return false;
}



void __stdcall hooks::paint_traverse::hook(unsigned int panel, bool force_repaint, bool allow_force) {
	auto panel_to_draw = fnv::hash(interfaces::panel->get_panel_name(panel));

	switch (panel_to_draw) {
	case fnv::hash("MatSystemTopPanel"):

		visuals::run();
		hitmarker.run();
		visuals::spectator_list();
		

		if (variables::watermark)
		{
			
			render::draw_filled_rect(9, 10, 60, 16, color(0, 0, 0, 255));
			render::draw_rect(9, 10, 60, 2, color(114, 179, 232, 255));

			render::text(11, 12, render::fonts::watermark2_font, "luxeware", false, color::white(255));
			render::text(27, 12, render::fonts::watermark2_font, "        .vip", false, color(114, 179, 232, 255));
			
			/*
			render::text(11, 10, render::fonts::watermark2_font, "luxeware", false, color::white(255));
			render::text(27, 10, render::fonts::watermark2_font, "        .vip", false, color(114, 179, 232, 255));

			render::draw_rect(9, 10, 60, 2, color(52, 134, 235, 255));
			//Blac bg
		
			//
			render::draw_rect(9, 10, 60, 13, color(1, 1, 1, 200));
			*/

		}


		menu::toggle();
		menu::render();

		break;

	case fnv::hash("FocusOverlayPanel"):
		interfaces::panel->set_keyboard_input_enabled(panel, variables::menu::opened);
		interfaces::panel->set_mouse_input_enabled(panel, variables::menu::opened);

		break;
	}

	switch (panel_to_draw) {
		

		break;
	}

	
	paint_traverse_original(interfaces::panel, panel, force_repaint, allow_force);
}

void __stdcall hooks::frame_stage_notify::hook(int frame_stage) {
	static int nightmode_value = 0;
	if (!interfaces::engine->is_in_game() || !interfaces::engine->is_connected()) {
		frame_stage_notify_original(interfaces::client, frame_stage);
		nightmode_value = 0;
		return;
	}



	if (frame_stage == FRAME_RENDER_START && csgo::local_player) 
	{

		static bool enabledtp = false, check = false;
		

			
			

			if (csgo::local_player && csgo::local_player->is_alive())
			{
				if (enabledtp)
				{
					*(bool*)((DWORD)interfaces::input + 0xAD) = true;
					*(float*)((DWORD)interfaces::input + 0xA8 + 0x8 + 0x8) = 150.f;
				}
				else
				{
					*(bool*)((DWORD)interfaces::input + 0xAD) = false;
					*(float*)((DWORD)interfaces::input + 0xA8 + 0x8 + 0x8) = 0.f;
				}
			}
			else
			{
				*(bool*)((DWORD)interfaces::input + 0xAD) = false;
				*(float*)((DWORD)interfaces::input + 0xA8 + 0x8 + 0x8) = 0.f;
			}
		
	
	}
	
	if (nightmode_value != variables::nightmode) {
		visuals::nightmode();
		nightmode_value = variables::nightmode;
	}
	frame_stage_notify_original(interfaces::client, frame_stage);
}


float __stdcall hooks::viewmodel_fov::hook() {
	return 68 + float(std::clamp(variables::viewmodel_fov, 0.f, 30.f));
}

