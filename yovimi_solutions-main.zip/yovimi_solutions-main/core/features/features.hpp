#pragma once
#include "../../dependencies/utilities/csgo.hpp"
#include "../menu/variables.hpp"


namespace aimbot {
	bool aim(c_usercmd* cmd);
	void smooth(vec3_t& viewangles, vec3_t& angles, int amount);
	void weapon_settings(weapon_t* weapon);
}


namespace misc {

	void clantag();


	namespace movement {
		void bunny_hop(c_usercmd* cmd);
	};
}

namespace visuals 
{
	void force_crosshair();
	void nightmode();
	void spectator_list();
	void run();
	void player_esp(player_t* entity);
	

}
