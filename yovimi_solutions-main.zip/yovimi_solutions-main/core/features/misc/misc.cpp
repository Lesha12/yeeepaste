#include "..\features\features.hpp"





void misc::movement::bunny_hop(c_usercmd* cmd) {
	if (!variables::test_bool)
		return;

	const int move_type = csgo::local_player->move_type();

	if (move_type == movetype_ladder || move_type == movetype_noclip || move_type == movetype_observer)
		return;

	if (!(csgo::local_player->flags() & fl_onground))
		cmd->buttons &= ~in_jump;
};



void misc::clantag() {
	static auto Folse = false;

	if (variables::clantag && interfaces::engine->is_connected() && interfaces::engine->is_in_game())
	{
		switch (int(interfaces::globals->cur_time * 2.4) % 10)
		{
		case 0: utilities::apply_clan_tag(("--------")); break;
		case 1: utilities::apply_clan_tag(("---ew---")); break;
		case 2: utilities::apply_clan_tag(("--xewa--")); break;
		case 3: utilities::apply_clan_tag(("-uxewar-")); break;
		case 4: utilities::apply_clan_tag(("luxeware")); break;
		case 5: utilities::apply_clan_tag(("luxeware")); break;
		case 6: utilities::apply_clan_tag(("luxeware")); break;
		case 7: utilities::apply_clan_tag(("-uxewar-")); break;
		case 8: utilities::apply_clan_tag(("--xewa--")); break;
		case 9: utilities::apply_clan_tag(("---ew---")); break;
		case 10: utilities::apply_clan_tag(("--------")); break;
		
	

		}


	}
	
	{
		if (Folse)
			static std::string tag = ("\n");
		Folse = false;
		return;
	}

	Folse = true;

	static std::string tag = " luxeware $ ";
	static float last_time = 0;

	if (interfaces::globals->cur_time > last_time) {
		std::rotate(std::begin(tag), std::next(std::begin(tag)), std::end(tag));
		utilities::apply_clan_tag(tag.c_str());

		last_time = interfaces::globals->cur_time + 0.9f;
	}

	if (fabs(last_time - interfaces::globals->cur_time) > 1.f)
		last_time = interfaces::globals->cur_time;


}

