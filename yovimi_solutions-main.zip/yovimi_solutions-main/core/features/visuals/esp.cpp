#include "esp.h"
//#include "C:\Users\yovimi\Documents\!csgo-cheat-base-master\core\menu\menu.cpp"
#include "..\features\features.hpp"
#include "..\menu\variables.hpp"
//#include "weaponinfo.h"


void visuals::run() {
	auto local_player = reinterpret_cast<player_t*>(interfaces::entity_list->get_client_entity(interfaces::engine->get_local_player()));

	if (interfaces::engine->is_taking_screenshot()) // hehe
		return;

	if (!local_player)
		return;

	//if (!variables::enablevis)
		//return;

	if (!interfaces::engine->is_connected())
		return;

	if (!interfaces::engine->is_in_game())
		return;



	for (int i = 1; i <= interfaces::globals->max_clients; i++)
	{
		auto entity = reinterpret_cast<player_t*>(interfaces::entity_list->get_client_entity(i));


		if (!entity)
			continue;

		const int fade = (int)((6.66666666667f * interfaces::globals->frame_time) * 255);

		auto new_alpha = alpha[i];
		new_alpha += entity->dormant() ? -fade : fade;

		if (new_alpha > (entity->has_gun_game_immunity() ? 130 : 210))
			new_alpha = (entity->has_gun_game_immunity() ? 130 : 210);

		alpha[i] = new_alpha;

		if (entity->team() == local_player->team() && !variables::teamesp)
			continue;


		if (entity == csgo::local_player)
			continue;

		if (entity->health() <= 0)
			continue;


		visuals::player_esp(entity);

		visuals::force_crosshair;

		
		

		if (variables::radarhack)
			entity->spotted() = true;

	}

}



void visuals::player_esp(player_t* entity)
{
	if (entity->dormant())
		return;

	player_info_t info;
	interfaces::engine->get_player_info(entity->index(), &info);
	auto local_player = reinterpret_cast<player_t*>(interfaces::entity_list->get_client_entity(interfaces::engine->get_local_player()));

	box b_box;
	if (!get_playerbox(entity, b_box))
		return;


	// name esp
	if (variables::nameesp)

	{
		wchar_t szString[5024];

		memset(szString, 0, sizeof(wchar_t) * 5024);
		info.name[16] = 0;
		strcat(info.name, "");
		puts(info.name);

		render::text(b_box.x + (b_box.w / 2) - 3, b_box.y - 20, render::fonts::watermark_font, info.name, true, color::white(255));

	}

	const int healtha = math::clamp(entity->health(), 0, 100);
	auto health_colora = color((255 - entity->health() * 2.55), (entity->health() * 2.55), 0, 255);

	box temp(b_box.x - 5, b_box.y + (b_box.h - b_box.h * (utilities::math::clamp_value<int>(entity->health(), 0, 100.f) / 100.f)), 1, b_box.h * (utilities::math::clamp_value<int>(entity->health(), 0, 100) / 100.f) - (entity->health() >= 100 ? 0 : -1));
	box temp_bg(b_box.x - 5, b_box.y, 1, b_box.h);


	auto health_color = color((255 - entity->health() * 2.55), (entity->health() * 2.55), 0, alpha[entity->index()]);

	if (entity->health() > 100)
		health_color = color(0, 255, 0, 255);

	if (variables::hpesp) ///hp esp


	{

		render::draw_filled_rect(temp_bg.x - 1, temp_bg.y - 1, temp_bg.w + 2, temp_bg.h + 2, color(0, 0, 0, 255));
		render::draw_filled_rect(temp.x, temp.y, temp.w, temp.h, color(health_color));
		render::text(temp.x - 12, temp.y, render::fonts::watermark_font, std::to_string(healtha), true, color(0, 0, 0, 255));
		render::text(temp.x - 12, temp.y, render::fonts::watermark_font, std::to_string(healtha), true, color(health_color));


	}


	if (variables::box) ///box

	{
		
		render::draw_outline(b_box.x - 1, b_box.y - 1, b_box.w + 2, b_box.h + 2, color(0, 0, 0, 255));
		render::draw_rect(b_box.x, b_box.y, b_box.w, b_box.h, color::white(255));
		render::draw_outline(b_box.x + 1, b_box.y + 1, b_box.w - 2, b_box.h - 2, color(0, 0, 0, 255));
	}

	if (variables::flags)
	{
		////FLAGS////
		std::vector<std::pair<std::string, color>> flags;

		if (variables::flags && entity->money())
			flags.push_back(std::pair<std::string, color>(std::string("$").append(std::to_string(entity->money())), color(120, 180, 10, 255)));


		if (variables::flags && entity->has_helmet() && entity->armor() > 0)
			flags.push_back(std::pair<std::string, color>("HK", color(255, 255, 255, 255)));
		else if (variables::flags && !entity->has_helmet() && entity->armor() > 0)
			flags.push_back(std::pair<std::string, color>("K", color(255, 255, 255, 255)));



		if (variables::flags && entity->is_scoped())
			flags.push_back(std::pair<std::string, color>(std::string("ZOOM"), color(80, 160, 200, 255)));

		if (variables::flags && entity->is_flashed())
			flags.push_back(std::pair<std::string, color>(std::string("FLASHED"), color(255, 225, 105, 255)));

		/*	if (vars::checkbox["#name_esp"]->get_bool() && entity->has_c4())
				flags.push_back(std::pair<std::string, color>(std::string("C4"), color(255, 255, 255, 255)));

			if (vars::checkbox["#name_esp"]->get_bool() && entity->is_flashed())
				flags.push_back(std::pair<std::string, color>(std::string("BLIND"), color(255, 255, 255, 255)));

			if (vars::checkbox["#name_esp"]->get_bool() && info.fakeplayer)
				flags.push_back(std::pair<std::string, color>(std::string("BOT"), color(205, 205, 255, 255)));*/

		auto position = 0;
		for (auto text : flags) {
			render::text(b_box.x + b_box.w + 3, b_box.y + position - 2, render::fonts::flags_font, text.first, false, text.second);
			position += 10;
		}
	}

	if (variables::ammo)
	{



		auto weapon = entity->active_weapon();


		if (!weapon)
			return;

		auto gun_ammo = weapon->clip1_count();

		auto math_for_the_ammo_bar = gun_ammo * b_box.w / weapon->get_weapon_data()->weapon_max_clip;

		int visible_ammo = weapon->get_weapon_data()->weapon_max_clip / 4;

		if (gun_ammo < 0) return;

		render::draw_filled_rect(b_box.x - 1, b_box.y + b_box.h + 3, b_box.w + 2, 4, color(0, 0, 0, 170));
		render::draw_filled_rect(b_box.x, b_box.y + b_box.h + 4, math_for_the_ammo_bar, 2, color(0, 50, 255));
		if (gun_ammo <= visible_ammo) {
			render::text((b_box.x + 10) + math_for_the_ammo_bar - 10, b_box.y + b_box.h - 2, render::fonts::watermark_font, std::to_string(gun_ammo), true, color(255, 255, 255, 255));
		}
	}

	if (variables::weaponesp)

	{
		auto weapon = entity->active_weapon();

		if (!weapon)
			return;

		std::string names;
		names = clean_item_name(weapon->get_weapon_data()->weapon_name);

		std::transform(names.begin(), names.end(), names.begin(), ::toupper);


		render::text(b_box.x + (b_box.w / 2) - 3, b_box.h + b_box.y + 2, render::fonts::watermark_font, names, true, color(255, 255, 255, 255));


	}


	


	if (variables::forcec)

	{


		if (!interfaces::engine->is_in_game())
			return;

		if (!csgo::local_player->is_scoped())
		{

			interfaces::engine->execute_cmd("weapon_debug_spread_show 3");
			return;
		}

		else
		{

			interfaces::engine->execute_cmd("weapon_debug_spread_show 0");
		}
	}


}

void visuals::spectator_list()
{

	if (variables::specs)

	{



		int kapi = 0;
		int screen_x, screen_y;

		interfaces::engine->get_screen_size(screen_x, screen_y);

		for (int i = 1; i <= 64; i++) {
			player_t* player = reinterpret_cast<player_t*>(interfaces::entity_list->get_client_entity(i));
			if (player) {
				auto handle = player->observer_target();
				if (handle)
				{
					player_t* target = reinterpret_cast<player_t*>(interfaces::entity_list->get_client_entity_handle(handle));
					if (target && target == csgo::local_player)
					{
						player_info_t spectator_info;
						interfaces::engine->get_player_info(player->index(), &spectator_info);
						std::string spectator_name = spectator_info.name;
						if (spectator_info.fakeplayer) spectator_name += " (BOT)";

						render::text(1200, screen_y / 2 - 80 + 22 * kapi, render::fonts::watermark_font, spectator_name, false, color::white(250));
						kapi ++;
					}
				}
			}
		}


		render::draw_filled_rect(1193, screen_y / 2 - 90 - 18, 80, 19, color(0, 0, 0, 255));
		render::draw_rect(1193, screen_y / 2 - 90 - 18, 80, 2, color(114, 179, 232, 255));
		render::text(1200, screen_y / 2 - 90 - 15 , render::fonts::watermark_font, "   Spectators", false, color::white(220));
		

	}

}



void visuals::nightmode() {
	static convar* draw_specific_static_prop = interfaces::console->get_convar("r_drawspecificstaticprop");
	if (draw_specific_static_prop->get_int() != 0)
		draw_specific_static_prop->set_value(0);

	for (mat_handle_t i = interfaces::material_system->first_material(); i != interfaces::material_system->invalid_material_handle(); i = interfaces::material_system->next_material(i))
	{
		i_material* material = interfaces::material_system->get_material(i);
		if (!material)
			continue;

		if (strstr(material->get_texture_group_name(), "World") || strstr(material->get_texture_group_name(), "StaticProp"))
		{
			float nightmode_value = (100.f - float(variables::nightmode)) / 100.f;
			float props_value = std::clamp(nightmode_value + 0.3f, 0.00f, 1.00f);

			if (variables::nightmode > 0) {
				if (strstr(material->get_texture_group_name(), "StaticProp"))
					material->color_modulate(props_value, props_value, props_value);
				else
					material->color_modulate(nightmode_value, nightmode_value, nightmode_value);
			}
			else
				material->color_modulate(1.0f, 1.0f, 1.0f);
		}
	}
}















	

	/*if  (!variables::weaponesp)
		return;
	{
		auto weapon = entity->active_weapon();

		if (!weapon)
			return;

		std::string names;
		names = clean_item_name(weapon->get_weapon_data()->m_szWeaponName);

		std::transform(names.begin(), names.end(), names.begin(), ::toupper);


		render::text(b_box.x + (b_box.w / 2) - 3, b_box.h + b_box.y + 2, render::fonts::watermark_font, names, true, color(255, 255, 255, 255));


	}

}*/

