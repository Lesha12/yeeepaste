#include "menu.hpp"

//todo auto elements positioning

auto do_frame = [&](std::int32_t x, std::int32_t y, std::int32_t w, std::int32_t h, color bg, color header_text, color header_line, const std::string& name , const std::string& name2) {
	//	render::draw_filled_rect(x, y, w, h, bg);
		render::draw_filled_rect(x, y, w, 30, color (0, 0 ,0 , 255));
		render::draw_filled_rect(x, y + 30, w, 2, color (52, 134, 235, 255));
		render::text(x + 10, y + 7 ,render::fonts::logo_font, name, false, color::white());
		render::text(x + 31, y + 7 ,render::fonts::logo_font, name2 , false, color(52, 134, 235, 255));
	    
};


void menu::render() {
	

	if (!variables::menu::opened)
		return;

	do_frame(variables::menu::x, variables::menu::y, variables::menu::w, variables::menu::h, color(0, 0, 0, 255), color(0, 0, 0, 255), color(0, 0, 0, 255), "luxeware" , "        .vip");


	
	menu_framework::group_box(variables::menu::x + 1, variables::menu::y + 300, 400, 35, render::fonts::watermark_font, "tabs", false); {
		menu_framework::tab(variables::menu::x + 5, variables::menu::y + (260 / 2) + 175, 100, 30, render::fonts::watermark_font, "aimbot", menu::current_tab, 0, false);
		menu_framework::tab(variables::menu::x + 105, variables::menu::y + (260 / 2) + 175, 100, 30, render::fonts::watermark_font, "visuals", menu::current_tab, 1, false);
		menu_framework::tab(variables::menu::x + 205, variables::menu::y + (260 / 2) + 175, 100, 30, render::fonts::watermark_font, "misc", menu::current_tab, 2, false);
		menu_framework::tab(variables::menu::x + 305, variables::menu::y + (260 / 2) + 175, 100, 30, render::fonts::watermark_font, "config", menu::current_tab, 3, false);
	}

	switch (current_tab) {
	case 0:
		menu_framework::group_box(variables::menu::x + 1, variables::menu::y + 35, 400, 260, render::fonts::watermark_font, "aimbot", false); {
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 50, variables::menu::x + 15, render::fonts::watermark_font, "silent", variables::silent);
			menu_framework::slider(variables::menu::x + 30, variables::menu::y + 75, 125, render::fonts::watermark_font, "fov", variables::afov, 0.f, 180.f);
			menu_framework::slider(variables::menu::x + 30, variables::menu::y + 100, 125, render::fonts::watermark_font, "rcs", variables::rcsf, 0.f, 100.f);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 125, variables::menu::x + 15, render::fonts::watermark_font, "backtrack", variables::backt);
			menu_framework::slider(variables::menu::x + 30, variables::menu::y + 150, 125, render::fonts::watermark_font, "backtrack value", variables::backa, 0.f, 200.f);
			menu_framework::slider(variables::menu::x + 30, variables::menu::y + 175, 125, render::fonts::watermark_font, "smooth", variables::smth, 1.f, 10.f);
		}
		break;
	case 1:
		menu_framework::group_box(variables::menu::x + 1, variables::menu::y + 35, 400, 260, render::fonts::watermark_font, "visuals", false); {
			//tab 1

			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 50, variables::menu::x + 15, render::fonts::watermark_font, "name", variables::nameesp);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 75, variables::menu::x + 15, render::fonts::watermark_font, "box", variables::box);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 100, variables::menu::x + 15, render::fonts::watermark_font, "hp bar", variables::hpesp);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 125, variables::menu::x + 15, render::fonts::watermark_font, "active weapon", variables::weaponesp);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 150, variables::menu::x + 15, render::fonts::watermark_font, "flags", variables::flags);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 175, variables::menu::x + 15, render::fonts::watermark_font, "ammo bar", variables::ammo);

			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 200, variables::menu::x + 15, render::fonts::watermark_font, "force croshair", variables::forcec);

			menu_framework::slider(variables::menu::x + 30, variables::menu::y + 225, 125, render::fonts::watermark_font, "viewmodel fov", variables::viewmodel_fov, 0.f, 30.f);

			menu_framework::slider(variables::menu::x + 30, variables::menu::y + 250, 125, render::fonts::watermark_font, "nightmode", variables::nightmode, 0.f, 100.f);

			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 275, variables::menu::x + 15, render::fonts::watermark_font, "grenade prediction", variables::nade);
			  

			//tab 2
			///hitsound & hitmarker not working
			//menu_framework::check_box(variables::menu::x + 300, variables::menu::y + 50, variables::menu::x + 285, render::fonts::watermark_font, "hitsound", variables::hitsound);
			//menu_framework::check_box(variables::menu::x + 300, variables::menu::y + 75, variables::menu::x + 285, render::fonts::watermark_font, "hitmarker", variables::hitmarker);

		}
		break;
	case 2:
		menu_framework::group_box(variables::menu::x + 1, variables::menu::y + 35, 400, 260, render::fonts::watermark_font, "misc", false); {

			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 50, variables::menu::x + 15, render::fonts::watermark_font, "bhop", variables::test_bool);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 75, variables::menu::x + 15, render::fonts::watermark_font, "watermark", variables::watermark);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 100, variables::menu::x + 15, render::fonts::watermark_font, "spectator list", variables::specs);
			menu_framework::check_box(variables::menu::x + 30, variables::menu::y + 125, variables::menu::x + 15, render::fonts::watermark_font, "clantag", variables::clantag);
		
		}
		break;
	case 3:
		menu_framework::group_box(variables::menu::x + 1, variables::menu::y + 35, 400, 260, render::fonts::watermark_font, "config", false); {

			
		

		}
		break;
	
	}

	menu_framework::menu_movement(variables::menu::x, variables::menu::y, variables::menu::w, 30);
}

void menu::toggle() {
	if (GetAsyncKeyState(VK_INSERT) & 1)
		variables::menu::opened = !variables::menu::opened;
}
