#pragma once

namespace variables {
	inline bool jump_bug = false;
	inline bool nade = false;
	inline bool hitsound = false;
	inline bool hitmarker = false;

	inline bool load = false;
	inline bool save = false;


	inline bool clantag = false;

	inline bool test_bool = false;
	inline bool watermark = true;

	inline float viewmodel_fov = 0.f;
	inline float nightmode = 0.f;
	inline bool specs = false;
	inline bool forcec = false;

	inline float test_float = 0.f;

	inline bool vel = false;
	inline bool velpre = false;
	inline float velpos = 0.f;


		inline bool enablevis = true;
		inline bool box = false;
		inline bool bShowInfo = false;
		 inline bool weaponesp = false;
		 inline bool nameesp = false;
		 inline bool ammo = false;
		 inline bool name2 = false;
		 inline bool teamesp = false;
		 inline bool radarhack = false;
		 inline bool flags = false;
		 inline bool hpesp = false;
		 inline bool aimon = true;
		 inline bool silent = false;
		 inline bool backt = false;

		 inline float afov = 0.f;
		 inline float rcsf = 0.f;
		 inline float smth = 1.f;
		 inline float backa = 0.f;

	namespace menu {
		inline bool opened = false;
		inline int x = 140, y = 140;
		inline int w = 400, h = 300;
	}
}