
struct view_setup_t {
	std::byte pad[176];
	float fov;
	std::byte pad1[32];
	float far_z;
};