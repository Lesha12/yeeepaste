# info [![Build status](https://ci.appveyor.com/api/projects/status/s9yhmm4ru6ywfsyt?svg=true)](https://ci.appveyor.com/project/designer1337/csgo-cheat-base) [![C++](https://img.shields.io/badge/language-C%2B%2B-%23f34b7d.svg)](https://en.wikipedia.org/wiki/C%2B%2B) [![CS:GO](https://img.shields.io/badge/game-CS%3AGO-yellow.svg)](https://store.steampowered.com/app/730/CounterStrike_Global_Offensive/) [![Windows](https://img.shields.io/badge/platform-Windows-0078d7.svg)](https://en.wikipedia.org/wiki/Microsoft_Windows)
credits: https://github.com/alphauc/sdk



# media
<a href="https://ibb.co/9qsLT7S"><img src="https://i.ibb.co/ZhWP807/Desktop-Screenshot-2021-06-30-21-56-44-87.png" alt="Desktop-Screenshot-2021-06-30-21-56-44-87" border="0"></a>


# change log

- new menu
- aimbot
- backtrack
- visuals
- clantag
- spectator list
- watermark


[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=yovimi)](https://github.com/anuraghazra/github-readme-stats)

