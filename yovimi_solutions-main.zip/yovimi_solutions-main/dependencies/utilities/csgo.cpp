#include "csgo.hpp"

namespace csgo {
	player_t* local_player = nullptr;
}
